from django.apps import AppConfig


class SitiowebConfig(AppConfig):
    name = 'sitioweb'
